CREATE DATABASE  IF NOT EXISTS `copi_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `copi_db`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: copi_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kpis`
--

DROP TABLE IF EXISTS `kpis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpis` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Nome` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `NivelId` int DEFAULT NULL,
  `EixoId` int DEFAULT NULL,
  `Pontuacao` double DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_KPIs_EixoId` (`EixoId`),
  KEY `IX_KPIs_NivelId` (`NivelId`),
  CONSTRAINT `FK_KPIs_Eixos_EixoId` FOREIGN KEY (`EixoId`) REFERENCES `eixos` (`Id`),
  CONSTRAINT `FK_KPIs_Niveis_NivelId` FOREIGN KEY (`NivelId`) REFERENCES `niveis` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpis`
--

LOCK TABLES `kpis` WRITE;
/*!40000 ALTER TABLE `kpis` DISABLE KEYS */;
INSERT INTO `kpis` VALUES (3,'NP.CAA.1 - Termo de Compromisso assinado e atualizado pela Autoridade Máxima do órgão',1,1,3.33),(4,'NP.CAA.2 - Equipe de Gestão Formalmente Designada',1,1,3.33),(7,'NP.CAA.3 - Participação da Alta Administração na supervisão (semestralmente)',1,1,3.33),(8,'NP.CIN.1 - Plano de Comunicação para a Integridade',1,2,5),(9,'NP.CIN.2 - 10% dos servidores participaram do curso de ética do CFCI',1,2,5),(10,'NP.GTR.1 - Publicação do PIBP no site institucional',1,3,3.33),(11,'NP.GTR.2 - Publicação das devolutivas ao PIBP no site institucional',1,3,3.33),(12,'NP.GTR.3 - Transparência CCF, Consulta Conflito e Canal de Denúncias',1,3,3.33),(13,'NP.GRI.1 - Existência de Plano de Gestão de Riscos para a Integridade',1,4,5),(14,'NP.GRI.2 - Entrega de relatório de monitoramento PIBP',1,4,5),(15,'NP.GIP.1 - Atendimento de, pelo menos, 25% das recomendações emitidas por CGM/AUDI',1,5,5),(16,'NP.GIP.2 - Declaração de Bens e Valores por 100% dos servidores',1,5,5),(17,'NI.CAA.1 - Participação da Alta Administração em ações de integridade (anualmente)',2,1,10),(18,'NI.CIN.1 - Servidores manifestam ciência ao Código de Conduta Funcional',2,2,3.33),(19,'NI.CIN.2 - 30% dos servidores participaram do curso de ética do CFCI',2,2,3.33),(20,'NI.CIN.3 - Promoção da ética junto aos Conselhos',2,2,3.33),(21,'NI.GTR.1 - Atualização CMBD',2,3,5),(22,'NI.GTR.2 - Manutenção do Selo de Acessibilidade Digital',2,3,5),(23,'NI.GRI.1 - Monitoramento contíno do Plano de Gestão de Riscos para a Integridade',2,4,5),(24,'NI.GRI.2 - Divulgação do status de implementação do PIBP',2,4,5),(25,'NI.GIP.1 - Atendimento de, pelo menos, 50% das recomendações emitidas por CGM/AUDI',2,5,2.5),(26,'NI.GIP.2 - Resposta às Reclamações da OGM no prazo',2,5,2.5),(27,'NI.GIP.3 - Atendimento das Recomendações do PIBP 70% ou mais',2,5,2.5),(28,'NI.GIP.4 - Certidões negativas CEI/CNEP',2,5,2.5),(29,'NG.CAA.1 - Existência de Unidade de Controle Interno ou equivalente',3,1,3.33),(30,'NG.CAA.2 - Unidade de Controle Interno com, pelo menos, 3 servidores, sendo 2 efetivos',3,1,3.33),(31,'NG.CAA.3 - Orçamento destinado à Unidade de Controle Interno',3,1,3.33),(32,'NG.CIN.1 - Código de Conduta específico',3,2,3.33),(33,'NG.CIN.2 - 50% ou mais dos servidores participaram do curso de ética do CFCI',3,2,3.33),(34,'NG.CIN.3 - Gestão e avaliação regular da área de controle interno ',3,2,3.33),(35,'NG.GTR.1 - Publicação interativa: gastos públicos semestrais',3,3,3.33),(36,'NG.GTR.2 - Publicação interativa: repasses e transferências',3,3,3.33),(37,'NG.GTR.3 - Existência de PSTDA e abertura no Portal Dados Abertos',3,3,3.33),(38,'NG.GRI.1 - Plano de Gestão de Riscos para a Integridade integrado ao Planejamento Estratégico',3,4,5),(39,'NG.GRI.2 - Abordagem metodológica de apetite ao risco',3,4,5),(40,'NG.GIP.1 - Atendimento de, pelo menos, 75% das recomendações emitidas por CGM/AUDI',3,5,2.5),(41,'NG.GIP.2 - Conclusão de Processo de Apuração Preliminar em 30 dias',3,5,2.5),(42,'NG.GIP.3 - 20% de negros, negras ou afrodescendentes em cargos em comissão e estágio profissional',3,5,2.5),(44,'NG.GIP.4 - Obtenção Nível Aprimorado e-Prevenção',3,5,2.5);
/*!40000 ALTER TABLE `kpis` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 10:58:57
