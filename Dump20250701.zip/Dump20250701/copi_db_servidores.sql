CREATE DATABASE  IF NOT EXISTS `copi_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `copi_db`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: copi_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `servidores`
--

DROP TABLE IF EXISTS `servidores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servidores` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Nome` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DivisaoId` int NOT NULL,
  `Celular` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Status` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CargoOuFuncao` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PontoSei` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ChefiaImediata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `RF` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `HorarioEntrada` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `HorarioSaida` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `DataCriacao` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `PasswordHash` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Role` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UltimoAcesso` datetime(6) DEFAULT NULL,
  `UserName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Servidores_DivisaoId` (`DivisaoId`),
  CONSTRAINT `FK_Servidores_Divisoes_DivisaoId` FOREIGN KEY (`DivisaoId`) REFERENCES `divisoes` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servidores`
--

LOCK TABLES `servidores` WRITE;
/*!40000 ALTER TABLE `servidores` DISABLE KEYS */;
INSERT INTO `servidores` VALUES (1,'Servidor de Teste','teste@prefeitura.sp.gov.br',1,'11999999999','Ativo','Analista','SEI-12345','Chefe Exemplo','1234567','08:00','17:00','2025-06-24 09:47:31.000000','$2a$11$B2KaZ5AgIz645SOHSl5xweaqnraFLiNhTxMvsyh1aTXaBxpV/A3hS','Admin',NULL,'teste'),(2,'Reinaldo Favoretto Santana','reinaldofs@prefeitura.sp.gov.br',1,'11991940490','Ativo','Assessor 1','Ponto SEI','Barbarah da Silva Dantas','9490876','08:00','17:00','2025-06-27 13:35:57.832787','$2a$11$s2D8epXP/a/n89Qehn6Va.spFFxPRAeLwlxWNLleCbznktRvwlxra','Admin',NULL,''),(3,'Barbarah da Silva Dantas','barbarah@prefeitura.sp.gov.br',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 14:42:27.475288','$2a$11$AUfUndiCXXuQI/kO7JZng.3cUZxmuxIvYc4JhQgnVOrtVNEhxuBCy','Admin',NULL,''),(5,'Jardel Soares Fernandes','jsfernandes@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 17:00:47.545528','$2a$11$dhGUWsamBlTvmkTgvbrNnOcyGiCU.LcVcotWR5e47SXS2CL3JUPkm','Gestor',NULL,''),(7,'Gabrielle Cattan','gabriellec@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 18:29:21.313727','$2a$11$JfP0lxqOo2B80JCB2ai2EedqT5gpeBF8VMwOg8FyQse0IVqZmarhi','UsuarioPlus',NULL,''),(8,'Francineide Mendes Rozado','fmrozado@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 18:38:12.442932','$2a$11$rIbLs/299YkR5f8GWnXKPuPDXf5y3YLKkuvadJTJhUJpF4PPbd9Z2','Usuario',NULL,''),(9,'Eden dos Santos Costa','edencosta@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 18:38:47.501409','$2a$11$1d0zemE8JIoJwmydQARpB.mE.QSE.4JK275LcqJPIH79OsDHt.08y','Usuario',NULL,''),(10,'Debora Yuri Dondo','dydondo@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 18:39:04.428633','$2a$11$1TXDp/E1Qs/ggVsvzNdQdeaJDuCThrVdd64RdZd1RoeMnEYh6PovG','Usuario',NULL,''),(11,'Debora Kerwald Pereira da Silva','deborakerwald@prefeitura.sp.gov.br',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-06-27 18:39:37.533370','$2a$11$EG2WM0pEK9vxBf2DBaZHWelJLd5ZyItPOB9aEbTOIDhi4nc9bGHEu','Usuario',NULL,'');
/*!40000 ALTER TABLE `servidores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 10:58:56
