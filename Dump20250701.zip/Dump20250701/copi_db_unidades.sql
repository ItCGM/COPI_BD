CREATE DATABASE  IF NOT EXISTS `copi_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `copi_db`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: copi_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `unidades`
--

DROP TABLE IF EXISTS `unidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidades` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Nome` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `NomeAbreviado` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidades`
--

LOCK TABLES `unidades` WRITE;
/*!40000 ALTER TABLE `unidades` DISABLE KEYS */;
INSERT INTO `unidades` VALUES (1,'Casa Civil','CCIVIL'),(2,'Controladoria Geral do Município','CGM'),(3,'Procuradoria Geral do Município','PGM'),(4,'Secretaria de Governo Municipal','SGM'),(5,'Secretaria Municipal da Fazenda','SF'),(6,'Secretaria Municipal da Pessoa com Deficiência','SMPED'),(7,'Secretaria Municipal da Saúde','SMS'),(8,'Secretaria Municipal das Subprefeituras','SMSUB'),(9,'Secretaria Municipal de Assistência e Desenvolvimento Social','SMADS'),(10,'Secretaria Municipal de Cultura e Economia Criativa','SMC'),(11,'Secretaria Municipal de Desenvolvimento Econômico e Trabalho ','SMDET'),(12,'Secretaria Municipal de Direitos Humanos e Cidadania','SMDHC'),(13,'Secretaria Municipal de Educação','SME'),(14,'Secretaria Municipal de Esportes e Lazer','SEME'),(15,'Secretaria Municipal de Gestão','SEGES'),(16,'Secretaria Municipal de Habitação','SEHAB'),(17,'Secretaria Municipal de Infraestrutura Urbana e Obras','SIURB'),(18,'Secretaria Municipal de Inovação e Tecnologia','SMIT'),(19,'Secretaria Municipal de Justiça','SMJ'),(20,'Secretaria Municipal de Mobilidade Urbana e Transporte ','SMT'),(21,'Secretaria Municipal de Planejamento e Eficiência','SEPLAN'),(22,'Secretaria Municipal de Relações Internacionais','SMRI'),(23,'Secretaria Municipal de Segurança Urbana','SMSU'),(24,'Secretaria Municipal de Turismo','SMTUR'),(25,'Secretaria Municipal de Urbanismo e Licenciamento','SMUL'),(26,'Secretaria Municipal do Verde e do Meio Ambiente','SVMA'),(27,'Subprefeitura Aricanduva/Formosa/Carrão','SUB-AF'),(28,'Subprefeitura Butantã','SUB-BT'),(29,'Subprefeitura Campo Limpo','SUB-CL'),(30,'Subprefeitura Capela do Socorro','SUB-CS'),(31,'Subprefeitura Casa Verde/Cachoeirinha','SUB-CV'),(32,'Subprefeitura Cidade Ademar','SUB-AD'),(33,'Subprefeitura Cidade Tiradentes','SUB-CT'),(34,'Subprefeitura Ermelino Matarazzo','SUB-EM'),(35,'Subprefeitura Freguesia/Brasilândia ','SUB-FB'),(36,'Subprefeitura Guaianases','SUB-G'),(37,'Subprefeitura Ipiranga','SUB-IP'),(38,'Subprefeitura Itaim Paulista','SUB-IT'),(39,'Subprefeitura Itaquera','SUB-IQ'),(40,'Subprefeitura Jabaquara','SUB-JÁ'),(41,'Subprefeitura Jaçanã/Tremembé','SUB-JT'),(42,'Subprefeitura Lapa','SUB-LA'),(43,'Subprefeitura M\'Boi Mirim ','SUB-MB'),(44,'Subprefeitura Mooca','SUB-MO'),(45,'Subprefeitura Parelheiros','SUB-PA'),(46,'Subprefeitura Penha','SUB-PE'),(47,'Subprefeitura Perus/Anhanguera','SUB-PR'),(48,'Subprefeitura Pinheiros','SUB-PI'),(49,'Subprefeitura Pirituba/Jaraguá','SUB-PJ'),(50,'Subprefeitura Santana/Tucuruvi','SUB-ST'),(51,'Subprefeitura Santo Amaro','SUB-SA'),(52,'Subprefeitura São Mateus','SUB-SM'),(53,'Subprefeitura São Miguel','SUB-MP'),(54,'Subprefeitura Sapopemba','SUB-SB'),(55,'Subprefeitura Sé','SUB-SÉ'),(56,'Subprefeitura Vila Maria/Vila Guilherme','SUB-MG'),(57,'Subprefeitura Vila Mariana','SUB-VM'),(58,'Subprefeitura Vila Prudente','SUB-VP'),(59,'Agência Reguladora de Serviços Públicos','SPREGULA'),(60,'Fundação Paulistana de Educação Tecnologia e Cultura','FUNDATEC'),(61,'Fundação Theatro Municipal de São Paulo ','FTMSP'),(62,'Hospital do Servidor Público Municipal','HSPM'),(63,'Instituto de Previdência Municipal de São Paulo','IPREM'),(64,'Agência São Paulo de Desenvolvimento','ADESAMPA'),(65,'São Paulo Negócios','SPNegócios'),(66,'Companhia de Engenharia e Tráfego','CET'),(67,'Companhia Metropolitana de Habitação de São Paulo','COHAB'),(68,'Companhia São Paulo de Desenvolvimento e Mobilização de Ativos ','SPDA'),(69,'Empresa de Cinema e Audiovisual de São Paulo','SPCINE'),(70,'Empresa de Tecnologia e Informação e Comunicação do Município de São Paulo','PRODAM'),(71,'São Paulo Obras','SPObras'),(72,'São Paulo Parcerias','SP Parcerias'),(73,'São Paulo Transporte','SPTrans'),(74,'São Paulo Turismo','SPTuris'),(75,'São Paulo Urbanismo','SP Urbanismo');
/*!40000 ALTER TABLE `unidades` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 10:58:56
